import FormEditUser from '../components/Users/FormEditUser'

const EditUser = () => {
    return (<>
            <FormEditUser />
        </>
    )
}

export default EditUser