import SkillList from '../components/Skills/SkillList'

const Skills = () => {
    return <section>
            <div className="list-movie">
                <SkillList />
            </div>
    </section>
}

export default Skills