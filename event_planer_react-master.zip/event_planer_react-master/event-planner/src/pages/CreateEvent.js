import CreateEvent from '../components/Events/CreateEvent'

const createEvent = () => {
    return <section>
            <div className="list-movie">
                <CreateEvent />
            </div>
    </section>
}

export default createEvent