import RatingComp from '../components/Rating/Ratings'

const Rating = () => {
    return <section>
            <div className="list-movie">
                <RatingComp />
            </div>
    </section>
}

export default Rating