import EventList from '../components/Events/EventList'

const Home = () => {
    return <section>
            <div className="list-movie">
                <EventList />
            </div>
    </section>
}

export default Home