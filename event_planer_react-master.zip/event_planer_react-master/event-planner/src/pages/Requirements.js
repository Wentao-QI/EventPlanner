import RequirementList from '../components/Skills/RequirementList'

const Requirements = () => {
    return <section>
            <div className="list-movie">
                <RequirementList />
            </div>
    </section>
}

export default Requirements